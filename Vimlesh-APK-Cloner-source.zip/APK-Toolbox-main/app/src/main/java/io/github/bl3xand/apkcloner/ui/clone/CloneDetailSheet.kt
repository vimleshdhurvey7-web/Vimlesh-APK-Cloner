package io.github.bl3xand.apkcloner.ui.clone

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.core.view.isInvisible
import androidx.core.view.isVisible
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import io.github.bl3xand.apkcloner.R
import io.github.bl3xand.apkcloner.data.CloneInfo
import io.github.bl3xand.apkcloner.databinding.SheetCloneDetailBinding
import io.github.bl3xand.apkcloner.sources.model.SettingKeys
import io.github.bl3xand.apkcloner.sources.ui.SourcesViewModel
import io.github.bl3xand.apkcloner.ui.apps.bind
import io.github.bl3xand.apkcloner.ui.confirm
import io.github.bl3xand.apkcloner.ui.main.MainActivity
import io.github.bl3xand.apkcloner.ui.main.MainViewModel
import io.github.bl3xand.apkcloner.ui.show
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class CloneDetailSheet : BottomSheetDialogFragment() {

    private var _binding: SheetCloneDetailBinding? = null
    private val binding get() = _binding!!
    private val viewModel: MainViewModel by activityViewModels()

    /** A clone that a source keeps current is updated and changed through the tracked apps. */
    private val sources: SourcesViewModel by activityViewModels()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = SheetCloneDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val packageName = requireArguments().getString(ARG_PACKAGE).orEmpty()
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                combine(viewModel.uiState, sources.repo.downloads, sources.lookingUp, ::Triple).collect { (state, downloads, lookingUp) ->
                    // Looked up on every change so the versions refresh right after an update,
                    // and the sheet goes away once the clone has been uninstalled.
                    val clone = state.clones.firstOrNull { it.app.packageName == packageName }
                    if (clone == null) dismiss()
                    else render(clone, state.updatingClone, state.uninstallingClone, working = clone.tracked?.app?.id in downloads || packageName in lookingUp)
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun render(clone: CloneInfo, updating: String?, uninstalling: String?, working: Boolean) {
        val busy = updating == clone.app.packageName || uninstalling == clone.app.packageName || working
        val missing = getString(R.string.detail_not_installed)
        val context = requireContext()
        val tracked = clone.tracked

        binding.appCard.bind(clone.app, clone.app.packageName)
        binding.textOriginal.text = clone.original?.let { "${it.label}\n${it.packageName}" } ?: clone.originalPackage
        binding.textCloneVersion.text = clone.app.versionName.orEmpty()
        // What the clone is rebuilt from when there is something newer: a source, or the installed app.
        binding.textUpdatedFrom.setText(if (clone.original != null) R.string.detail_from_original else R.string.detail_from_nothing)
        tracked?.let { binding.textUpdatedFrom.text = it.sourceName() }
        binding.textOriginalVersionTitle.setText(if (tracked != null) R.string.detail_latest_version else R.string.detail_original_version)
        binding.textOriginalVersion.text = tracked?.app?.latestVersion ?: clone.original?.let { it.versionName.orEmpty() } ?: missing

        // Shows what the clone was built without, so it is not a mystery later why something is off.
        val removed = tracked?.app?.cloneRemovedPermissions ?: clone.removedPermissions
        binding.dividerPermissions.isVisible = removed.isNotEmpty()
        binding.rowPermissions.isVisible = removed.isNotEmpty()
        if (removed.isNotEmpty()) binding.textPermissions.text = removed.sorted().joinToString("\n") { it.substringAfterLast('.') }

        // The same editor as when the clone was made. A change is applied by building the clone
        // again and installing it over itself, so the data is kept. Needs something to build from.
        val original = clone.original
        binding.permissions.buttonPermissions.text = context.clonePermissionsLabel(removed.size)
        binding.permissions.buttonPermissions.isEnabled = clone.canRebuild && !busy
        binding.permissions.buttonPermissions.setOnClickListener {
            if (tracked != null) {
                sources.clonePermissions(tracked.app.id) { id, requested ->
                    val app = sources.repo.entry(id)?.app ?: return@clonePermissions
                    context.pickClonePermissions(requested, app.cloneRemovedPermissions, fresh = app.cloneNewPermissions) {
                        sources.setClonePermissions(id, it, requested)
                    }
                }
            } else if (original != null) {
                context.pickClonePermissions(context.requestedPermissionsOf(original.apkPaths.first()), removed) { viewModel.setClonePermissions(clone, it) }
            }
        }
        binding.permissions.buttonResetPermissions.isVisible = removed.isNotEmpty()
        binding.permissions.buttonResetPermissions.isEnabled = clone.canRebuild && !busy
        binding.permissions.buttonResetPermissions.setOnClickListener {
            if (tracked != null) sources.setClonePermissions(tracked.app.id, emptySet(), tracked.app.cloneRequestedPermissions)
            else viewModel.setClonePermissions(clone, emptySet())
        }
        // The patches the clone was built with, shown and changed the same way as permissions:
        // the tracked app's set for a clone a source keeps current, what the APK records otherwise.
        val patches = tracked?.app?.clonePatches ?: clone.patches
        binding.permissions.buttonPatches.text = context.clonePatchesLabel(patches.size, context.clonePatches().size)
        binding.permissions.buttonPatches.isEnabled = clone.canRebuild && !busy
        binding.permissions.buttonPatches.setOnClickListener {
            context.pickClonePatches(context.clonePatches(), patches) { chosen ->
                if (tracked != null) sources.setClonePatches(tracked.app.id, chosen)
                else if (original != null) viewModel.setClonePatches(clone, chosen)
            }
        }
        // What the last build could not apply: the identity patch is dead without the original's
        // certificate, and a page that counts it as on would lie. The note stays until a build
        // that applies everything - a rebuild from a release whose certificate can be read.
        val notApplied = clone.patchesNotApplied
        binding.permissions.textPatchesNotApplied.isVisible = notApplied.isNotEmpty()
        if (notApplied.isNotEmpty()) {
            val names = context.clonePatches().associate { it.id to it.label }
            binding.permissions.textPatchesNotApplied.text =
                context.getString(R.string.clone_patches_not_applied, notApplied.sorted().joinToString { names[it] ?: it })
        }
        // A clone lives on what it is rebuilt from. One that has only an installed original - an
        // app from Google Play, say - can be handed to a source that carries the same app, and
        // then goes on being updated when the original is gone.
        binding.buttonShowTracked.isVisible = tracked != null
        binding.buttonShowTracked.setOnClickListener {
            val id = tracked?.app?.id ?: return@setOnClickListener
            dismiss()
            (activity as? MainActivity)?.showTrackedApp(id)
        }
        binding.buttonTrack.isVisible = tracked == null
        binding.buttonTrack.isEnabled = !busy
        binding.buttonTrack.setOnClickListener {
            viewLifecycleOwner.lifecycleScope.launch {
                if (context.confirm(getString(R.string.clone_track), getString(R.string.clone_track_message))) {
                    sources.trackClone(clone.originalPackage, clone.app.packageName)
                }
            }
        }

        binding.switchNoUpdates.isVisible = true
        binding.switchNoUpdates.setOnCheckedChangeListener(null)
        binding.switchNoUpdates.isChecked = clone.frozen
        binding.switchNoUpdates.isEnabled = !busy
        binding.switchNoUpdates.setOnCheckedChangeListener { _, on ->
            // A clone that a source keeps current has the setting there, with the tracked app.
            if (tracked != null) sources.update(listOf(tracked.app.id)) { it.withSetting(SettingKeys.NO_UPDATES, on) }
            else viewModel.setCloneFrozen(clone, on)
        }

        binding.actions.progress.show(
            busy,
            // The percent of a rebuild in progress; null (plain "working on it") for the rest.
            viewModel.rebuildPercent?.toDouble()?.takeIf { updating == clone.app.packageName },
        )
        binding.actions.buttonUpdate.isEnabled = clone.updateAvailable && !busy
        binding.actions.buttonDelete.isEnabled = !busy
        binding.actions.buttonUpdate.setOnClickListener {
            if (tracked != null) sources.obtain(listOf(tracked.app.id)) else viewModel.updateClone(clone)
        }
        // The system asks for confirmation; progress shows for the whole wait and the card closes
        // once the clone is gone.
        binding.actions.buttonDelete.setOnClickListener { viewModel.uninstallClone(clone) }
    }

    companion object {
        const val TAG = "clone-detail"
        private const val ARG_PACKAGE = "package"

        fun newInstance(clone: CloneInfo) = newInstance(clone.app.packageName)

        fun newInstance(packageName: String) = CloneDetailSheet().apply { arguments = bundleOf(ARG_PACKAGE to packageName) }
    }
}
