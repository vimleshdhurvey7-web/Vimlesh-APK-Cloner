package io.github.bl3xand.apkcloner.clone.dex

import io.github.bl3xand.apkcloner.clone.build.DexPatchChain
import org.jf.dexlib2.AccessFlags
import org.jf.dexlib2.Opcode
import org.jf.dexlib2.Opcodes
import org.jf.dexlib2.DexFileFactory
import org.jf.dexlib2.iface.DexFile
import org.jf.dexlib2.iface.Method
import org.jf.dexlib2.iface.instruction.Instruction
import org.jf.dexlib2.iface.instruction.ReferenceInstruction
import org.jf.dexlib2.iface.reference.MethodReference
import org.jf.dexlib2.iface.reference.StringReference
import org.jf.dexlib2.immutable.ImmutableDexFile
import org.jf.dexlib2.immutable.ImmutableMethod
import org.jf.dexlib2.immutable.ImmutableMethodImplementation
import org.jf.dexlib2.immutable.ImmutableMethodParameter
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction10x
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction21c
import org.jf.dexlib2.immutable.instruction.ImmutableInstruction35c
import org.jf.dexlib2.immutable.reference.ImmutableMethodReference
import org.jf.dexlib2.immutable.reference.ImmutableStringReference
import org.jf.dexlib2.writer.pool.DexPool
import java.io.File

/**
 * Unit tests for the dex patchers, on synthetic dex files built with dexlib2 itself: each test
 * assembles a minimal dex whose code says exactly what the test wants to say, runs a patch over
 * it and inspects the result. Fail-safety (garbage in, same bytes out) is covered too.
 */
class DexPatchTest {

    // ---- helpers to build and read synthetic dex files ----

    private fun dex(vararg methods: Triple<String, String, List<ImmutableInstruction>>): ByteArray {
        val classDef = org.jf.dexlib2.immutable.ImmutableClassDef(
            "Ltest/Synth;",
            AccessFlags.PUBLIC.value,
            "Ljava/lang/Object;",
            emptyList<String>(),
            null,
            emptyList<org.jf.dexlib2.iface.Annotation>(),
            emptyList<org.jf.dexlib2.iface.Field>(),
            methods.map { (name, descriptor, instructions) ->
                ImmutableMethod(
                    "Ltest/Synth;", name,
                    listOf<org.jf.dexlib2.iface.MethodParameter>(ImmutableMethodParameter("I", emptySet(), null)),
                    "V",
                    AccessFlags.PUBLIC.value or AccessFlags.STATIC.value,
                    emptySet(), emptySet(),
                    ImmutableMethodImplementation(instructions.size + 2, instructions + ImmutableInstruction10x(Opcode.RETURN_VOID), emptyList(), emptyList()),
                )
            },
        )
        val output = File.createTempFile("synth", ".dex")
        try {
            DexPool.writeTo(output.absolutePath, ImmutableDexFile(Opcodes.getDefault(), listOf(classDef)))
            return output.readBytes()
        } finally {
            output.delete()
        }
    }

    private fun load(data: ByteArray): DexFile {
        val input = File.createTempFile("synth_in", ".dex")
        try {
            input.writeBytes(data)
            return DexFileFactory.loadDexFile(input, Opcodes.getDefault())
        } finally {
            input.delete()
        }
    }

    /** All (class, name, opcode) of every method-reference instruction in the dex. */
    private fun methodCalls(data: ByteArray): List<Triple<String, String, Opcode>> =
        load(data).classes.flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
            .filterIsInstance<ReferenceInstruction>()
            .map { it.reference as MethodReference }
            .map { Triple(it.definingClass, it.name, Opcode.INVOKE_STATIC) }

    /** All strings of every const-string instruction in the dex. */
    private fun stringConstants(data: ByteArray): List<String> =
        load(data).classes.flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
            .filter { it.opcode == Opcode.CONST_STRING }
            .map { (it as ReferenceInstruction).reference as StringReference }
            .map { it.string }

    private fun invokeStatic(clazz: String, name: String, params: List<String> = listOf("I"), ret: String = "V") =
        ImmutableInstruction35c(Opcode.INVOKE_STATIC, params.size.coerceAtMost(5), 0, 0, 0, 0, 0, ImmutableMethodReference(clazz, name, params, ret))

    private fun constString(s: String) = ImmutableInstruction21c(Opcode.CONST_STRING, 0, ImmutableStringReference(s))

    /** The instructions of every method of every class (or of [only] one class) in the dex. */
    private fun instructionsOf(data: ByteArray, only: String? = null): List<Instruction> =
        load(data).classes.filter { only == null || it.type == only }
            .flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }

    // ---- KeepAlive ----

    @org.junit.Test
    fun keepAliveNopsSystemExit() {
        val before = dex(Triple("a", "(I)V", listOf(invokeStatic("Ljava/lang/System;", "exit"))))
        val after = KeepAlive.patchDex(before)
        val calls = methodCalls(after)
        org.junit.Assert.assertTrue("System.exit must be gone", calls.none { it.first == "Ljava/lang/System;" && it.second == "exit" })
        // the no-op replacement keeps the instruction count: the invoke became a 10x nop
        val nops = load(after).classes.flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
            .count { it.opcode == Opcode.NOP }
        org.junit.Assert.assertTrue("expected a nop where the invoke was", nops >= 1)
    }

    @org.junit.Test
    fun keepAliveNopsProcessKillAndFinish() {
        val before = dex(
            Triple("a", "(I)V", listOf(invokeStatic("Landroid/os/Process;", "killProcess"))),
            Triple("b", "(I)V", listOf(invokeStatic("Landroid/app/Activity;", "finish", listOf(), "V"))),
        )
        val after = KeepAlive.patchDex(before)
        val calls = methodCalls(after)
        org.junit.Assert.assertTrue(calls.none { it.second == "killProcess" || it.second == "finish" })
    }

    @org.junit.Test
    fun keepAliveLeavesOtherCallsAlone() {
        val before = dex(Triple("a", "(I)V", listOf(invokeStatic("Ljava/lang/Math;", "abs", listOf("I"), "I"))))
        org.junit.Assert.assertArrayEquals("no self-exit calls: bytes must be unchanged", before, KeepAlive.patchDex(before))
    }

    @org.junit.Test
    fun keepAliveFailSafeOnGarbage() {
        val garbage = byteArrayOf(1, 2, 3, 4)
        org.junit.Assert.assertArrayEquals(garbage, KeepAlive.patchDex(garbage))
    }

    // ---- SignatureBypass ----

    @org.junit.Test
    fun bypassNopsTheGuardExitAndKeepsTheDexLoadable() {
        // A guard method: reads the signature, then kills the process on mismatch.
        val before = dex(
            Triple("a", "(I)V", listOf(
                invokeStatic("Landroid/content/pm/PackageManager;", "getPackageSignatures", listOf("Ljava/lang/String;", "I"), "[Landroid/content/pm/Signature;"),
                invokeStatic("Ljava/lang/System;", "exit"),
            )),
        )
        val after = SignatureBypass.patchDex(before)
        val calls = methodCalls(after)
        org.junit.Assert.assertTrue("the guard's System.exit must be gone", calls.none { it.first == "Ljava/lang/System;" && it.second == "exit" })
        org.junit.Assert.assertTrue("the signature read must stay", calls.any { it.second == "getPackageSignatures" })
        // Size-preserving no-ops: one 10x nop per code unit of the replaced invoke (3 for a 35c).
        val nops = instructionsOf(after).count { it.opcode == Opcode.NOP }
        org.junit.Assert.assertEquals("3 nops replace the 3-unit invoke", 3, nops)
        // The patched dex has to stay a dex ART can load and verify, not just bytes.
        load(after).classes.forEach { cls ->
            cls.methods.forEach { m ->
                m.implementation?.let { impl ->
                    impl.instructions.forEach { require(it.codeUnits > 0) }
                    impl.tryBlocks.forEach { require(it.startCodeAddress >= 0 && it.codeUnitCount > 0) }
                }
            }
        }
    }

    @org.junit.Test
    fun bypassLeavesOtherExitsAlone() {
        // System.exit WITHOUT a signature read in the same method must not be touched.
        val before = dex(
            Triple("a", "(I)V", listOf(invokeStatic("Ljava/lang/System;", "exit"))),
            Triple("b", "(I)V", listOf(
                invokeStatic("Landroid/content/pm/Signature;", "getMessageDigest", listOf("Ljava/lang/String;"), "[B"),
                invokeStatic("Ljava/lang/Math;", "abs", listOf("I"), "I"),
            )),
        )
        org.junit.Assert.assertArrayEquals("no guard method: bytes must be unchanged", before, SignatureBypass.patchDex(before))
    }

    @org.junit.Test
    fun bypassFailSafeOnGarbage() {
        val garbage = byteArrayOf(5, 5, 5)
        org.junit.Assert.assertArrayEquals(garbage, SignatureBypass.patchDex(garbage))
    }

    // ---- SignatureSpoof ----

    @org.junit.Test
    fun spoofRetargetsGetPackageInfo() {
        val before = dex(
            Triple("a", "(I)V", listOf(invokeStatic("Landroid/content/pm/PackageManager;", "getPackageInfo", listOf("Ljava/lang/String;", "I"), "Landroid/content/pm/PackageInfo;"))),
        )
        val after = SignatureSpoof.patchDex(before, "classes.dex", byteArrayOf(1, 2, 3), "com.example.app", "com.example.app.clone")
        val calls = load(after).classes.flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
            .filterIsInstance<ReferenceInstruction>()
            .mapNotNull { (it.reference as? MethodReference) }
        org.junit.Assert.assertTrue(
            "getPackageInfo must be retargeted to the helper",
            calls.any { it.definingClass == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" && it.name == "get" },
        )
        org.junit.Assert.assertTrue("original target must be gone",
            load(after).classes.filter { it.type != "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" }
                .flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
                .filterIsInstance<ReferenceInstruction>()
                .none { (it.reference as? MethodReference)?.name == "getPackageInfo" })
    }

    @org.junit.Test
    fun spoofInjectsHelperOnlyIntoPrimaryDex() {
        val before = dex(Triple("a", "(I)V", listOf(constString("x"))))
        val primary = SignatureSpoof.patchDex(before, "classes.dex", byteArrayOf(1), "com.example.app", "com.example.app.clone", spoofName = true)
        val secondary = SignatureSpoof.patchDex(before, "classes2.dex", byteArrayOf(1), "com.example.app", "com.example.app.clone")
        org.junit.Assert.assertTrue(load(primary).classes.any { it.type == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" })
        org.junit.Assert.assertFalse(load(secondary).classes.any { it.type == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" })
    }

    @org.junit.Test
    fun spoofHelperSubstitutesOnTheSuccessPathToo() {
        // The helper's contract, in code-unit shape:
        // - the try must NOT return the successful getPackageInfo result: the classic
        //   self-check queries the app by its own (visible) package name, which goes through
        //   the SUCCESS path - returning the real info there hands the app the CLONER's
        //   certificate. The success result must instead jump over the NameNotFoundException
        //   handler into the shared substitution tail, so both paths return the info with the
        //   ORIGINAL's certificate written into `signatures`;
        // - the handler compares the queried name against the CLONE's and the ORIGINAL's
        //   package; only those retry with the clone's package (mimicry's redirect), any
        //   other absent/invisible package rethrows NameNotFoundException - the app keeps its
        //   unpatched behavior for foreign-package queries.
        val before = dex(
            Triple("a", "(I)V", listOf(invokeStatic("Landroid/content/pm/PackageManager;", "getPackageInfo", listOf("Ljava/lang/String;", "I"), "Landroid/content/pm/PackageInfo;"))),
        )
        val after = SignatureSpoof.patchDex(before, "classes.dex", byteArrayOf(1, 2, 3), "com.example.app", "com.example.app.clone")
        val gets = load(after).classes.first { it.type == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" }
            .methods.filter { it.name == "get" }
        org.junit.Assert.assertEquals("one helper get() per flags type", 2, gets.size)
        for (get in gets) {
            val impl = get.implementation!!
            // (instruction, code-unit address) of the whole method, to reason about the layout.
            val withAddr = impl.instructions.toList().zip(impl.instructions.toList().runningFold(0) { addr, ins -> addr + ins.codeUnits }.dropLast(1))
            // Exactly one return, at the very end, after the signatures iput: shared by the
            // success path and the handler's retry.
            val returns = withAddr.filter { it.first.opcode == Opcode.RETURN_OBJECT }
            org.junit.Assert.assertEquals("exactly one return, at the end of the tail", 1, returns.size)
            val iputs = withAddr.filter { it.first.opcode == Opcode.IPUT_OBJECT }
            org.junit.Assert.assertEquals("exactly one signatures iput, before the return", 1, iputs.size)
            org.junit.Assert.assertTrue(
                "the iput must precede the return (substitution applies to the returned info)",
                withAddr.indexOfFirst { it == iputs.first() } < withAddr.indexOfFirst { it == returns.first() },
            )
            // The success path must not return before the substitution: a GOTO sits right after
            // the try's move-result and jumps over the handler into the tail.
            val gotos = withAddr.filter { it.first.opcode == Opcode.GOTO }
            org.junit.Assert.assertEquals("one goto over the handler", 1, gotos.size)
            org.junit.Assert.assertEquals(
                "the goto is the third instruction (invoke, move-result, goto)",
                2, withAddr.indexOfFirst { it == gotos.first() },
            )
            val gotoAddr = gotos.first().second
            val handlerStart = impl.tryBlocks.first().exceptionHandlers.first().handlerCodeAddress
            org.junit.Assert.assertTrue(
                "the goto jumps from inside the try over the handler into the tail",
                gotoAddr < handlerStart && gotoAddr + (gotos.first().first as org.jf.dexlib2.iface.instruction.formats.Instruction10t).codeOffset > handlerStart,
            )
            // Every branch must land on an INSTRUCTION BOUNDARY and reach the code it guards:
            // the two 22t branches are the name guard's (clone-name-miss -> original compare,
            // original-name-hit -> retry). A branch whose offset was written as an absolute
            // address instead of a relative one lands mid-instruction - ART rejects the whole
            // class with "tried to get class from non-reference register" (upx.61's first
            // runtime iteration), so the targets are pinned here exactly.
            val instructionStarts = withAddr.map { it.second }.toSet()
            val branches = withAddr.filter { it.first.opcode == Opcode.IF_NE || it.first.opcode == Opcode.IF_EQ }
            org.junit.Assert.assertEquals("two guard branches", 2, branches.size)
            val ifNe = branches.first { it.first.opcode == Opcode.IF_NE }
            val ifEq = branches.first { it.first.opcode == Opcode.IF_EQ }
            val ifNeTarget = ifNe.second + (ifNe.first as org.jf.dexlib2.iface.instruction.formats.Instruction22t).codeOffset
            val ifEqTarget = ifEq.second + (ifEq.first as org.jf.dexlib2.iface.instruction.formats.Instruction22t).codeOffset
            org.junit.Assert.assertTrue("the clone-name miss lands on the original-name compare", ifNeTarget in instructionStarts)
            org.junit.Assert.assertTrue("the original-name hit lands on the retry", ifEqTarget in instructionStarts)
            org.junit.Assert.assertTrue(
                "the retry target is the retry block's head (const-string, move-object, then the second invoke)",
                ifEqTarget + 3 == withAddr.filter { it.first.opcode == Opcode.INVOKE_VIRTUAL }.map { it.second }.sorted()[1],
            )
            org.junit.Assert.assertTrue(
                "the goto lands on an instruction boundary (the tail start)",
                gotoAddr + (gotos.first().first as org.jf.dexlib2.iface.instruction.formats.Instruction10t).codeOffset in instructionStarts,
            )
            // Units: invoke=3 + move-result=1 + goto=1, so the handler starts at unit 5 and the
            // try covers 0..5. ImmutableTryBlock is (start, codeUnitCount, handlers).
            org.junit.Assert.assertEquals(1, impl.tryBlocks.count())
            val tryBlock = impl.tryBlocks.first()
            org.junit.Assert.assertEquals(0, tryBlock.startCodeAddress)
            org.junit.Assert.assertEquals(5, tryBlock.codeUnitCount)
            org.junit.Assert.assertEquals(5, tryBlock.exceptionHandlers.first().handlerCodeAddress)
            org.junit.Assert.assertEquals(
                "Landroid/content/pm/PackageManager\$NameNotFoundException;",
                tryBlock.exceptionHandlers.first().exceptionType,
            )
            // The handler's re-query must ask for the CLONE's package (the always-visible
            // self), guarded by both names (clone first, then original), and the spoofing
            // tail must still write the signatures field before returning.
            val strings = withAddr.filter { it.first.opcode == Opcode.CONST_STRING }
                .map { ((it.first as ReferenceInstruction).reference as StringReference).string }
            org.junit.Assert.assertEquals(
                "the guard and the retry carry both names, clone twice",
                listOf("com.example.app.clone", "com.example.app", "com.example.app.clone"),
                strings.filter { it.startsWith("com.example.") },
            )
            org.junit.Assert.assertTrue(
                "the handler rethrows for names that are neither the clone's nor the original's",
                withAddr.any { it.first.opcode == Opcode.THROW },
            )
            val throwAddr = withAddr.filter { it.first.opcode == Opcode.THROW }.first().second
            org.junit.Assert.assertTrue(
                "the rethrow must be outside the try's covered range (it propagates out)",
                throwAddr >= tryBlock.startCodeAddress + tryBlock.codeUnitCount,
            )
            org.junit.Assert.assertTrue(
                "the tail still substitutes the signature",
                withAddr.any { it.first.opcode == Opcode.IPUT_OBJECT && (it.first as ReferenceInstruction).let { r -> (r.reference as org.jf.dexlib2.iface.reference.FieldReference).name == "signatures" } },
            )
        }
    }

    @org.junit.Test
    fun spoofApplicationInfoHelperHasNoTrysAndBranchesOnBoundaries() {
        // The applicationInfo helper must decide the substitution BEFORE its single call, from
        // the two names it owns - no NameNotFoundException catch, no retry: a wrong try-block
        // offset here produced a VerifyError on a real app ("target dex pc not at instruction
        // start"), and a retry re-asks the manager the same question it just failed to answer.
        val before = dex(
            Triple("a", "(I)V", listOf(invokeStatic("Landroid/content/pm/PackageManager;", "getApplicationInfo", listOf("Ljava/lang/String;", "I"), "Landroid/content/pm/ApplicationInfo;"))),
        )
        val after = SignatureSpoof.patchDex(before, "classes.dex", byteArrayOf(1, 2, 3), "com.example.app", "com.example.app.clone", spoofName = true)
        val helper = load(after).classes.first { it.type == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" }
        val methods = helper.methods.filter { it.name == "applicationInfo" }
        org.junit.Assert.assertEquals("one helper applicationInfo per flags type", 2, methods.size)
        for (method in methods) {
            val impl = method.implementation!!
            val withAddr = impl.instructions.toList().zip(impl.instructions.toList().runningFold(0) { addr, ins -> addr + ins.codeUnits }.dropLast(1))
            // No exception machinery at all: the helper cannot fail the way a bad try offset does.
            org.junit.Assert.assertEquals("no try blocks", 0, impl.tryBlocks.count())
            org.junit.Assert.assertFalse(withAddr.any { it.first.opcode == Opcode.THROW || it.first.opcode == Opcode.MOVE_EXCEPTION })
            // Every branch lands on an instruction boundary.
            val instructionStarts = withAddr.map { it.second }.toSet()
            for ((ins, addr) in withAddr) {
                when (ins.opcode) {
                    Opcode.IF_NE, Opcode.IF_EQ -> {
                        val target = addr + (ins as org.jf.dexlib2.iface.instruction.formats.Instruction22t).codeOffset
                        org.junit.Assert.assertTrue("branch target must be an instruction start", target in instructionStarts)
                    }
                    Opcode.GOTO -> {
                        val target = addr + (ins as org.jf.dexlib2.iface.instruction.formats.Instruction10t).codeOffset
                        org.junit.Assert.assertTrue("goto target must be an instruction start", target in instructionStarts)
                    }
                    else -> {}
                }
            }
            // Two invokes: the pass-through for foreign names and the clone-self answer.
            val invokes = withAddr.filter { it.first.opcode == Opcode.INVOKE_VIRTUAL }
            org.junit.Assert.assertEquals("one pass-through call and one self call", 2, invokes.size)
            // The self-answer path re-points the name register at the clone's package first.
            val cloneNames = withAddr.filter { it.first.opcode == Opcode.CONST_STRING }
                .map { ((it.first as ReferenceInstruction).reference as StringReference).string }
            org.junit.Assert.assertEquals(
                "the clone name is written into v4 (the query register) before the self call",
                listOf("com.example.app.clone", "com.example.app", "com.example.app.clone"),
                cloneNames,
            )
            // Register count: the params are v3..v5, scratch is v0-v2 at most.
            org.junit.Assert.assertTrue(impl.registerCount in 5..6)
        }
    }

    @org.junit.Test
    fun spoofRetargetsGetApplicationInfo() {
        val before = dex(
            Triple("a", "(I)V", listOf(invokeStatic("Landroid/content/pm/PackageManager;", "getApplicationInfo", listOf("Ljava/lang/String;", "I"), "Landroid/content/pm/ApplicationInfo;"))),
        )
        val after = SignatureSpoof.patchDex(before, "classes.dex", byteArrayOf(1, 2, 3), "com.example.app", "com.example.app.clone", spoofName = true)
        val calls = load(after).classes.flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
            .filterIsInstance<ReferenceInstruction>()
            .mapNotNull { (it.reference as? MethodReference) }
        org.junit.Assert.assertTrue(
            "getApplicationInfo must be retargeted to the helper under the name spoof",
            calls.any { it.definingClass == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" && it.name == "applicationInfo" },
        )
        org.junit.Assert.assertTrue(
            "the app's own getApplicationInfo call must be gone",
            load(after).classes.filter { it.type != "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" }
                .flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
                .filterIsInstance<ReferenceInstruction>()
                .none { (it.reference as? MethodReference)?.name == "getApplicationInfo" },
        )
    }

    @org.junit.Test
    fun spoofFailSafeOnGarbage() {
        val garbage = byteArrayOf(9, 9)
        org.junit.Assert.assertArrayEquals(garbage, SignatureSpoof.patchDex(garbage, "classes.dex", byteArrayOf(1), "com.example.app", "com.example.app.clone"))
    }

    @org.junit.Test
    fun spoofRetargetsGetPackageName() {
        val before = dex(
            Triple("a", "(I)V", listOf(
                ImmutableInstruction35c(
                    Opcode.INVOKE_VIRTUAL, 1, 0, 0, 0, 0, 0,
                    ImmutableMethodReference("Landroid/content/Context;", "getPackageName", listOf(), "Ljava/lang/String;"),
                ),
            )),
        )
        val after = SignatureSpoof.patchDex(before, "classes.dex", byteArrayOf(1), "com.example.app", "com.example.app.clone", spoofName = true)
        val calls = load(after).classes.flatMap { it.methods.toList() }.flatMap { it.implementation!!.instructions.toList() }
            .filterIsInstance<ReferenceInstruction>()
            .mapNotNull { (it.reference as? MethodReference) }
        org.junit.Assert.assertTrue(
            "getPackageName must be retargeted to the helper",
            calls.any { it.definingClass == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" && it.name == "packageName" },
        )
        val helper = load(after).classes.first { it.type == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" }
        val strings = helper.methods.flatMap { it.implementation!!.instructions.toList() }
            .filter { it.opcode == Opcode.CONST_STRING }
            .map { ((it as ReferenceInstruction).reference as StringReference).string }
        org.junit.Assert.assertTrue("helper carries the original package name", strings.contains("com.example.app"))
    }

    // ---- CoreRenameAlias ----

    @org.junit.Test
    fun renameAliasRewritesPackageStringOnly() {
        val before = dex(
            Triple("a", "(I)V", listOf(constString("com.example.app"), constString("com.example.app.extra"))),
        )
        val after = CoreRenameAlias.patchDex(before, "com.example.app", "com.example.app.clone")
        val strings = stringConstants(after)
        org.junit.Assert.assertEquals(listOf("com.example.app.clone", "com.example.app.extra"), strings)
    }

    @org.junit.Test
    fun renameAliasNoOriginalStringMeansUnchanged() {
        val before = dex(Triple("a", "(I)V", listOf(constString("something.else"))))
        org.junit.Assert.assertArrayEquals(before, CoreRenameAlias.patchDex(before, "com.example.app", "com.example.app.clone"))
    }

    @org.junit.Test
    fun renameAliasFailSafeOnGarbage() {
        val garbage = byteArrayOf(7)
        org.junit.Assert.assertArrayEquals(garbage, CoreRenameAlias.patchDex(garbage, "a.b", "a.b.c"))
    }

    // ---- the chain: patches compose ----

    @org.junit.Test
    fun chainKeepsTheMimicryHelperOriginalStringWithRenameAliasOn() {
        // RENAME_ALIAS + SPOOF_SIGNATURE + MIMICRY together: the alias rewriter rewrites every
        // const-string equal to the original package, and the mimicry helper's payload IS the
        // original's package name. With the alias running AFTER the spoof (the old chain order)
        // the helper's string was rewritten to the clone's package - mimicry silently inverted
        // into reporting exactly what an unpatched clone reports. The chain must inject the
        // helper only after the alias pass is done.
        val before = dex(
            Triple("a", "(I)V", listOf(
                constString("com.example.app"),
                invokeStatic("Landroid/content/pm/PackageManager;", "getPackageInfo", listOf("Ljava/lang/String;", "I"), "Landroid/content/pm/PackageInfo;"),
            )),
        )
        val original = "com.example.app"
        val clone = "com.example.app.clone"
        val chain = DexPatchChain(
            setOf(PatchIds.RENAME_ALIAS, PatchIds.SPOOF_SIGNATURE, PatchIds.MIMICRY),
            byteArrayOf(1, 2, 3), { original }, clone,
        )
        val after = chain.apply("classes.dex", before)

        // The app's own alias string was rewritten: core/plugin binding resolves under the clone.
        // (Scoped to the app class - the helper carries its own, deliberately different strings.)
        val appStrings = load(after).classes.first { it.type == "Ltest/Synth;" }
            .methods.flatMap { it.implementation!!.instructions.toList() }
            .filter { it.opcode == Opcode.CONST_STRING }
            .map { ((it as ReferenceInstruction).reference as StringReference).string }
            .filter { it.startsWith("com.example.") }
        org.junit.Assert.assertEquals("the app's alias string is rewritten", listOf(clone), appStrings)

        // The helper still reports the ORIGINAL's package name, and its getPackageInfo helper is
        // in place with the clone-package retry - mimicry intact, not inverted.
        val helper = load(after).classes.first { it.type == "Lio/github/bl3xand/apkcloner/spoof/SignatureSource;" }
        val helperStrings = helper.methods.flatMap { it.implementation!!.instructions.toList() }
            .filter { it.opcode == Opcode.CONST_STRING }
            .map { ((it as ReferenceInstruction).reference as StringReference).string }
        org.junit.Assert.assertTrue("the mimicry helper keeps the ORIGINAL package", helperStrings.contains(original))
        org.junit.Assert.assertTrue("the helper's retry keeps the CLONE package", helperStrings.contains(clone))
        org.junit.Assert.assertTrue(
            "getPackageInfo is retargeted to the helper",
            helper.methods.any { it.name == "get" },
        )
    }

    @org.junit.Test
    fun chainRenameAliasAloneStillRewrites() {
        // The reorder must not change what RENAME_ALIAS does on its own: no certificate, no
        // spoof - the alias still rewrites the original's package string.
        val before = dex(Triple("a", "(I)V", listOf(constString("com.example.app"))))
        val chain = DexPatchChain(setOf(PatchIds.RENAME_ALIAS), null, { "com.example.app" }, "com.example.app.clone")
        val after = chain.apply("classes.dex", before)
        org.junit.Assert.assertEquals(listOf("com.example.app.clone"), stringConstants(after))
    }

}
